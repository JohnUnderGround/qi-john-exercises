public class Quarter {
    
    protected int birthOfUser;

    public Quarter() {

    }
    
    public int getBirthOfUser() {
        return this.birthOfUser;
    }
    
    public void setBirthOfUser(int birthOfUser) {
        this.birthOfUser = birthOfUser;
    }
    
    public String verifyQuarter() {

        if(this.birthOfUser >= 13 ) {
            return "inválido";
        } else if(this.birthOfUser <= 12 ) {
            return "3 quarter";
        } else if(this.birthOfUser >= 4) {
            return "2 quarter";
        } else if(this.birthOfUser >= 1 ) {
            return "1 quarter";
        } else 
            return "invalid!";
    }


    @Override
    public String toString() {
        return "\nBirth: " + this.birthOfUser
        + "\nQuarter type: " + this.verifyQuarter();

    }
}