import java.util.Scanner;

public class Main{

    public static void main (String args[]) {

        System.out.println("\f");
        System.out.println("Quarter's Software");

        Scanner scanner = new Scanner(System.in);
        
        Quarter quarter = new Quarter();
        System.out.println("Type the mounth you were born: ");
        quarter.setBirthOfUser(scanner.nextInt());

        System.out.println(quarter);
    }
    
}