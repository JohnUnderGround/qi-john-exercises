import org.junit.Test;

import static org.junit.Assert.*;

public class VetorTest {

    Vetor vetor = new Vetor();

    @Test
    public void testCalcularIdadeMeses() {
        assertEquals(12, vetor.calcularIdade());
    }

    @Test
    public void testCalcularIdadeSemanas() {
    }

    @Test
    public void testVerificarOpcao() {
    }

    @Test
    public void testVerificarOpcaoString() {
    }
}